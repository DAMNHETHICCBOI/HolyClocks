<?php

declare (strict_types=1);

namespace HolyClocks;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\entity\EffectInstance;
use pocketmine\entity\Effect;
use pocketmine\entity\Living;
use pocketmine\utils\TextFormat as TF;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\item;
use pocketmine\item\ItemIds;
use pocketmine\entity\EntityEvent;


class Main extends PluginBase implements Listener {

	public function onEnable()
	{
		$this->getServer()->getLogger()->info(TF::GREEN . "HolyClocks made by TurtleSh0ck was successfully enabled");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
         public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        switch ($command->getName()) {

            case "hc":
                if ($sender instanceof Player) {
                    if (empty($args[0])) {
                        $sender->sendMessage(TF::RED . "Usage: /hc give (player) (amount)");
                        return true;
                    }
                    switch ($args[0]) {
                        case "give":
                            if (empty($args[1])) {
                                $sender->sendMessage(TF::RED . "Usage: /hc give (player) (amount)");
                                return true;
                            }
                            $player = $this->getServer()->getPlayer($args[1]);
                            if ($player === null) {
                                $sender->sendMessage(TF::RED . "Player is offline");
                                return true;
                            }
                            $clock = Item::get(Item::CLOCK);
                            $clock->setCustomName(TF::WHITE . "§lHoly Clock");
                            $clock->setLore([TF::GREEN . "§a§lTap to remove bad effects!\n\n§l§f[§cRARE ITEM§r§f]"]);
                            if (empty($args[2])) {
                                $sender->sendMessage(TF::RED . "Usage: /hc give (player) (amount)");
                                return true;
                            }
                            for ($count = $args[2] ?? 1; $count > 0; --$count) {
                                $player->getInventory()->addItem(clone $clock); 
    
                            }
                    }
                }
        }
        return true;
    }

                        public function onInteract(PlayerInteractEvent $event) {
                        if($event->getItem()->getId() === 347) {       
                        $item = $event->getItem();
                        $player = $event->getPlayer();
                        $inv = $player->getInventory();
                        $item = $inv->getItemInHand();
                        $item->count--;
                        $inv->setItemInHand($item);
                        $sender = $player->getPlayer();
                        if ($sender instanceof Player) {
                        	foreach ($sender->getEffects() as $effect) {
                               if ($effect->getType()->isBad()) {
                                   $sender->removeEffect($effect->getId());
                                   $sender->sendPopup("§aThe curse has been removed!");
                                   
                              }
                          }
        
      }                   
   }
}
}